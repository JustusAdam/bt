# Ÿauhau

> Concise code and efficient IO, get it for free with data flow.
