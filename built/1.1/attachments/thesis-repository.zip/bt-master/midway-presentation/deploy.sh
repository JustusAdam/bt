rsync -r beamer/main.pdf justusad@octans.uberspace.de:/var/www/virtual/justusad/static.justus.science/presentations/extending-yauhau.pdf
