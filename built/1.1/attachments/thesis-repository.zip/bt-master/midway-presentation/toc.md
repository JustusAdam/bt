0. Motivation
    - Large scale industrial sytems, microservices bla bla bla
-- TOC --
1. Prior approaches
    - Haxl and Muse
2. Ÿauhau and Ohua
    - Differences to previous approaches
    - Problems with control flow
3. Context and control flow
    - Context is a property of subgraphs emerging from node labels and not visible structurally
    - inherited property for non-context nodes
4. Unwinding context
    - Main part of the thesis
    - Generalised dispatch based on context type
    - Done??
5. Remaining work
    - Write semantics
    - Optimisations
    - Experiments


- Haxl und muse implementation as appendix

- Motivating example
- Application
- Ÿauhau
    - Example with transformation
- Level graphs extensions
